
demo link - https://weather-smoky-nine-38.vercel.app/

![Screenshot (93)](https://github.com/RuchiAgrawal9186/CodeClause/assets/112552732/ae0e2047-7342-46b1-be75-3b85194338ce)

![Screenshot (94)](https://github.com/RuchiAgrawal9186/CodeClause/assets/112552732/881f7066-6fb5-4b1a-813f-d08add8ff605)

![Screenshot (95)](https://github.com/RuchiAgrawal9186/CodeClause/assets/112552732/09a13c08-5185-4b3a-aa11-0b8d0777ec09)