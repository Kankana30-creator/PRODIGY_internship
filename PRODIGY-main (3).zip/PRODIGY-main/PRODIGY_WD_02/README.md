
demo link - https://stopwatch-rose.vercel.app/

![Screenshot (96)](https://github.com/RuchiAgrawal9186/PRODIGY/assets/112552732/92025cda-7ae9-42f9-92b0-4f8e981e3b10)

![Screenshot (97)](https://github.com/RuchiAgrawal9186/PRODIGY/assets/112552732/d74b7ce2-c733-4e6f-afa3-3d46c7defd8e)

![Screenshot (98)](https://github.com/RuchiAgrawal9186/PRODIGY/assets/112552732/ff919966-c807-4f40-9074-c7e0e07a2b8c)
