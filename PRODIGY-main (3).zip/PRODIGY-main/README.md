# PRODIGY

Its 4 week online internship program for we development Domain where they provide some task and we have to complete the task and get the internship completion certificate and also get opportunity for letter of recommendation (LOR)

wesite link - https://prodigyinfotech.dev/

Task 1 - Landing Page
demo link - https://landing-page-omega-eight-79.vercel.app/

Task 2 - Stop Watch
demo link - https://stopwatch-rose.vercel.app/

Task 4 - Portfolio
demo link - https://portfolio-puce-delta-99.vercel.app/

Task 5 - Weather app
demo link - https://weather-smoky-nine-38.vercel.app/