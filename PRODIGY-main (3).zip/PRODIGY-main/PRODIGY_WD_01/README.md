demo link - https://landing-page-omega-eight-79.vercel.app/

![Screenshot (65)](https://github.com/RuchiAgrawal9186/CVIP_Web_Development/assets/112552732/e1889206-2425-4e2f-9588-b7aeaa58a4f9)

![Screenshot (66)](https://github.com/RuchiAgrawal9186/CVIP_Web_Development/assets/112552732/eb440806-19f5-416d-a2c6-cb2b1231990d)

![Screenshot (67)](https://github.com/RuchiAgrawal9186/CVIP_Web_Development/assets/112552732/d9d00729-bb52-4c33-9f1a-5cfadba2dc02)

![Screenshot (68)](https://github.com/RuchiAgrawal9186/CVIP_Web_Development/assets/112552732/01663108-abe6-45c6-a2db-7f5e946c2e93)

![Screenshot (69)](https://github.com/RuchiAgrawal9186/CVIP_Web_Development/assets/112552732/85a87047-451d-4ef1-a885-62b6c558a1d3)